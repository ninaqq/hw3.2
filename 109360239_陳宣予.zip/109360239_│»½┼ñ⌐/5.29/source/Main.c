#include <stdio.h>
#include <stdlib.h>

int gcd(int gcd);
int lcm(int lcm);	
int in[2], ans1, ans2;
int max_buf = 0;
int cnt = 0;
int main()
{


	printf("�п�J��Ӽ�=");
	scanf_s("%d%d", &in[0], &in[1]);

	printf("gcd=%d\nlcd=%d", gcd(ans1), lcm(ans2));

	return 0;
}
int gcd(int ans1)
{
	for (int i = 0; i <= 1; i++)
	{
		if (in[i] > max_buf)
			max_buf = in[i];
	}

	for (int i = 1; i <= max_buf; i++)
	{
		if ((in[0] % i == 0) && (in[1] % i == 0))
			ans1 = i;
	}

	return ans1;
}
int lcm(int ans2)
{
	while (1)
	{
		if ((cnt%in[0] == 0) && (cnt%in[1] == 0))
		{
			if ((cnt >= in[0]) && (cnt >= in[1]))
			{
				ans2 = cnt;
				break;
			}
		}
		cnt = cnt + 1;
	}
	return ans2;
}