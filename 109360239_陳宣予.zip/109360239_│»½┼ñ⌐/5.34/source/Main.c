#include <stdio.h>
#include <stdlib.h> 

float pow(float a, int b);
int main()
{
	float c;
	int d;

	printf("�п�Jc��d����(d>0):");
	scanf_s("%f%d", &c, &d);
	printf("%f", pow(c, d));

}
float pow(float a, int b)
{
	float i, x = 1;

	for (i = 1; i <= b; i++)
	{
		x = a * x;
	}
	return x;
}