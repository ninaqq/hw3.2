#include <stdio.h>
#include <stdlib.h>

char alphabetTransform(char);

int main()
{
	char alphabet;
	printf("�п�J�r��:");
	scanf_s("%c", &alphabet);
	printf("%c", alphabetTransform(alphabet));


	return 0;
}

char alphabetTransform(char alphabet_in)
{
	if (alphabet_in >= 65 && alphabet_in <= 90)	//�j�g��p�g 
		return alphabet_in + 32;
	else if (alphabet_in >= 97 && alphabet_in <= 122)	//�p�g��j�g 
		return alphabet_in - 32;
}