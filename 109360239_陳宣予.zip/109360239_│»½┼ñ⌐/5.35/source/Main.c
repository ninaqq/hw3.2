#include <stdio.h>
#include <stdlib.h> 

unsigned long long int fibonacci(unsigned int);

int main()
{
	unsigned int n;
	long long int max = 1;
	unsigned int n_cnt = 0;

	//a)
	printf("a)\nEnter n: ");
	scanf_s("%u", &n);

	printf("\nThe %u(th) Fibonacci number is %llu", n, fibonacci(n));


	//b)
	printf("\n\nb)\n");

	while (max >= 0)
	{
		puts("");

		max = fibonacci(n_cnt);
		printf("n=%u: %lld", n_cnt, max);

		n_cnt++;
	}

	n_cnt -= 2;

	printf("(overflow)\n\n");
	printf("The largest Fibonacci number that can be print on my system is %llu", fibonacci(n_cnt));


	return 0;
}


unsigned long long int fibonacci(unsigned int n_in)
{
	int a;
	a = n_in;
	if (n_in <= 1)
		return n_in;
	else
	{
		int sum[100] = { 0 };
		sum[0] = 0;
		sum[1] = 1;

		for (int i = 2; i <= n_in; i++)
			sum[i] = sum[i - 1] + sum[i - 2];

		return sum[n_in];
	}

}